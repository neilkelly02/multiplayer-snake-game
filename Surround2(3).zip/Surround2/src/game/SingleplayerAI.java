package game;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

public class SingleplayerAI {

    public static String[] biasQuad = { "", "nw", "ne", "sw" };
    public static int targetX = 0;
    public static int targetY = 0;

    public static void getIdealDirection1(int id) {
        int[][] tempGrid = Board.getGrid();
        int cX = Board.getPlayers()[id].getLocationX();
        int cY = Board.getPlayers()[id].getLocationY();
        int w = 1;
        int a = 1;
        int s = 1;
        int d = 1;
        while (true) {
            if (tempGrid[cX][cY - w] != 0)
                break;
            w++;
        }
        while (true) {
            if (tempGrid[cX - a][cY] != 0)
                break;
            a++;
        }
        while (true) {
            if (tempGrid[cX][cY + s] != 0)
                break;
            s++;
        }
        while (true) {
            if (tempGrid[cX + d][cY] != 0)
                break;
            d++;
        }
        TreeMap<Integer, Character> sortMap = new TreeMap<>();
        sortMap.put(w, 'w');
        sortMap.put(a, 'a');
        sortMap.put(s, 's');
        sortMap.put(d, 'd');
        // return sortMap.lastEntry().getValue();
        try {
            Board.move(id, sortMap.lastEntry().getValue());
        } catch (Exception e) {

        }
    }

    public static void getIdealQuad(int id) {
        int[][] tempGrid = Board.getGrid();
        int cX = Board.getPlayers()[id].getLocationX();
        int cY = Board.getPlayers()[id].getLocationY();
        int nw = 0;
        int ne = 0;
        int sw = 0;
        int se = 0;
        for (int i = 0; i < cX; i++) {
            for (int j = 0; j < cY; j++) {
                if (tempGrid[i][j] == 0) nw++;
            }
        }
        for (int i = cX + 1; i < tempGrid.length; i++) {
            for (int j = 0; j < cY; j++) {
                if (tempGrid[i][j] == 0) ne++;
            }
        }
        for (int i = 0; i < cX; i++) {
            for (int j = cY + 1; j < tempGrid.length; j++) {
                if (tempGrid[i][j] == 0) sw++;
            }
        }
        for (int i = cX + 1; i < tempGrid.length; i++) {
            for (int j = cY + 1; j < tempGrid.length; j++) {
                if (tempGrid[i][j] == 0) se++;
            }
        }
        TreeMap<Integer, String> sortMap = new TreeMap<>();
        sortMap.put(nw, "nw");
        sortMap.put(ne, "ne");
        sortMap.put(sw, "sw");
        sortMap.put(se, "se");
        biasQuad[id] = sortMap.lastEntry().getValue();
    }

    public static char getIdealDirection2(int id) {
        int[][] tempGrid = Board.getGrid();
        int cX = Board.getPlayers()[id].getLocationX();
        int cY = Board.getPlayers()[id].getLocationY();
        boolean[] safe = new boolean[4]; //w, a, s, d
        if (tempGrid[cX][cY - 1] == 0) safe[0] = true;
        if (tempGrid[cX - 1][cY] == 0) safe[1] = true;
        if (tempGrid[cX][cY + 1] == 0) safe[2] = true;
        if (tempGrid[cX + 1][cY] == 0) safe[3] = true;
        if (biasQuad[id].equals("nw")) {
            if (Math.pow(cX, 2) + Math.pow(cY, 2) < 100) {
                biasQuad[id] = "se";
            }
            if (safe[0] == true && safe[1] == true) {
                if (Math.random() < 0.5) return 'w';
                else return 'a';
            }
            if (safe[0] == true) return 'w';
            else if (safe[1] == true) return 'a';
            if (safe[2] == true && safe[3] == true) {
                if (Math.random() < 0.5) return 's';
                else return 'd';
            }
            if (safe[2] == true) return 's';
            else if (safe[3] == true) return 'd';
        }
        else if (biasQuad[id].equals("ne")) {
            if (Math.pow(cX - tempGrid.length, 2) + Math.pow(cY, 2) < 100) {
                biasQuad[id] = "sw";
            }
            if (safe[0] == true && safe[3] == true) {
                if (Math.random() < 0.5) return 'w';
                else return 'd';
            }
            if (safe[0] == true) return 'w';
            else if (safe[3] == true) return 'd';
            if (safe[1] == true && safe[2] == true) {
                if (Math.random() < 0.5) return 'a';
                else return 's';
            }
            if (safe[1] == true) return 'a';
            else if (safe[2] == true) return 's';
        }
        else if (biasQuad[id].equals("sw")) {
            if (Math.pow(cX, 2) + Math.pow(cY - tempGrid.length, 2) < 100) {
                biasQuad[id] = "ne";
            }
            if (safe[2] == true && safe[1] == true) {
                if (Math.random() < 0.5) return 's';
                else return 'a';
            }
            if (safe[2] == true) return 's';
            else if (safe[1] == true) return 'a';
            if (safe[0] == true && safe[3] == true) {
                if (Math.random() < 0.5) return 'w';
                else return 'd';
            }
            if (safe[0] == true) return 'w';
            else if (safe[3] == true) return 'd';
        }
        else if (biasQuad[id].equals("se")) {
            if (Math.pow(cX - tempGrid.length, 2) + Math.pow(cY - tempGrid.length, 2) < 100) {
                biasQuad[id] = "nw";
            }
            if (safe[2] == true && safe[3] == true) {
                if (Math.random() < 0.5) return 's';
                else return 'd';
            }
            if (safe[2] == true) return 's';
            else if (safe[3] == true) return 'd';
            if (safe[0] == true && safe[1] == true) {
                if (Math.random() < 0.5) return 'w';
                else return 'a';
            }
            if (safe[0] == true) return 'w';
            else if (safe[1] == true) return 'a';
        }
        return '0';
    }

    public static void localDetect(int id) {    
        int[][] tempGrid = Board.getGrid();
        int cX = Board.getPlayers()[id].getLocationX();
        int cY = Board.getPlayers()[id].getLocationY();
        int dangerLevel = 0;
        for (int i = -2; i < 3; i++) {
            for (int j = -2; j < 3; j++) {
                if (tempGrid[cX + i][cY + j] != 0) dangerLevel++;
                if (i > -2 && i < 2 && j > -2 && j < 2 && tempGrid[cX + i][cY + j] != 0) dangerLevel++;
            }
        }
        if (dangerLevel > 20) {
            System.out.println("Fill");
            getIdealDirection3(id);
        }
        else {
            getIdealDirection1(id);
        }
    }

    static class Point {
        private int x;
        private int y;

        public Point(int xCoord, int yCoord) {
            this.x = xCoord;
            this.y = yCoord;
        }

        public int getX() {
            return this.x;
        }

        public int getY() {
            return this.y;
        }
    }

    static class Stack {
        private ArrayList<Point> stack;

        public Stack() {

        }

        public void push(Point o) {
            stack.add(o);
        }

        public Point pop() {
            Point popper = stack.get(stack.size() - 1);
            stack.remove(popper);
            return popper;
        }

        public Point peek() {
            return stack.get(stack.size() - 1);
        }

        public boolean isEmpty() {
            return stack.size() == 0;
        }

        public ArrayList<Point> getList() {
            return stack;
        }
    }

    public static void getIdealDirection3(int id) {
        TreeMap<Integer, Character> openSpace = new TreeMap<Integer, Character>();

        int[][] tempGrid = Board.getGrid();
        int cX = Board.getPlayers()[id].getLocationX();
        int cY = Board.getPlayers()[id].getLocationY();

        HashMap<Character, Integer> validDirections = new HashMap<Character, Integer>();
        validDirections.put('w', 0);
        validDirections.put('a', 0);
        validDirections.put('s', 0);
        validDirections.put('d', 0);

        for (int i = 1; i < 3; i++) {
            if (tempGrid[cX][cY - i] != 0) {
                validDirections.put('w', i);
            } else {
                break;
            }
        }

        for (int i = 1; i < 3; i++) {
            if (tempGrid[cX - i][cY] != 0) {
                validDirections.put('a', i);
            } else {
                break;
            }
        }
        for (int i = 1; i < 3; i++) {
            if (tempGrid[cX][cY + i] != 0) {
                validDirections.put('s', i);
            } else {
                break;
            }
        }
        for (int i = 1; i < 3; i++) {
            if (tempGrid[cX + i][cY] != 0) {
                validDirections.put('d', i);
            } else {
                break;
            }
        }

        if (validDirections.get('w') > 0) {
            openSpace.put(fillSpace('w', cX, cY - validDirections.get('w')), 'w');
        }

        if (validDirections.get('a') > 0) {
            openSpace.put(fillSpace('a', cX - validDirections.get('a'), cY), 'a');
        }

        if (validDirections.get('s') > 0) {
            openSpace.put(fillSpace('s', cX, cY + validDirections.get('s')), 's');
        }

        if (validDirections.get('d') > 0) {
            openSpace.put(fillSpace('d', cX + validDirections.get('d'), cY), 'd');
        }

        //return openSpace.lastEntry().getValue();
        try {
            Board.move(id, openSpace.lastEntry().getValue());
        } catch (Exception e) {

        }

    }

    public static int fillSpace(char direction, int x, int y) {
        Stack stack = new Stack();
        stack.push(new Point(x, y));

        int[][] tempGrid = Board.getGrid();
        if (direction == 'w') // creating U shapes
        {
            tempGrid[x - 1][y] = -1;
            tempGrid[x + 1][y] = -1;
            tempGrid[x][y + 1] = -1;
        } else if (direction == 'a') {
            tempGrid[x][y + 1] = -1;
            tempGrid[x][y - 1] = -1;
            tempGrid[x + 1][y] = -1;
        } else if (direction == 's') {
            tempGrid[x - 1][y] = -1;
            tempGrid[x + 1][y] = -1;
            tempGrid[x][y + 1] = -1;
        } else if (direction == 'd') {
            tempGrid[x - 1][y] = -1;
            tempGrid[x + 1][y] = -1;
            tempGrid[x][y + 1] = -1;
        }

        ArrayList<Point> visited = new ArrayList<Point>();

        while (!stack.isEmpty()) {
            Point currentPoint = stack.pop();
            visited.add(currentPoint);

            int tempX = currentPoint.getX();
            int tempY = currentPoint.getY();

            ArrayList<Point> adjacent = new ArrayList<Point>();
            adjacent.add(new Point(tempX - 1, tempY));
            adjacent.add(new Point(tempX, tempY + 1));
            adjacent.add(new Point(tempX + 1, tempY));
            adjacent.add(new Point(tempX, tempY - 1));

            for (Point p : adjacent) {
                if (p.getX() < Runner.GRID_SIZE && p.getY() < Runner.GRID_SIZE && p.getX() > 0 && p.getY() > 0) {
                    if (tempGrid[p.getX()][p.getY()] == 0) {
                        if (!visited.contains(p)) {
                            stack.push(p);
                        }
                    }
                }
            }
        }

        return visited.size();
    }
    
}
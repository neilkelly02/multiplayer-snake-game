package game;

import java.util.Timer;
import java.util.TimerTask;

public class Singleplayer {

    public static Timer gameTick = new Timer();
    public static int tickSpeed = 200;
    public static char direction = 'w';
    public static int totalPlayers;

    public Singleplayer(int totalPlayersIn) {
        totalPlayers = totalPlayersIn;
        startTimer();
    }

    public static void startTimer() {
        TimerTask tick = new TimerTask() {
            @Override
            public void run() {
                for (int i = 0; i < totalPlayers; i++) {
                    try {
                        if (Board.terminate() == true) {
                            gameTick.cancel();
                        }
                        if (Board.getLosers()[i] == false) {
                            if (i == 0) Board.move(i, direction);
                            else SingleplayerAI.localDetect(i);
                        }
                    } catch (Exception e) {

                    }
                }
            }
        };
        gameTick.scheduleAtFixedRate(tick, tickSpeed, tickSpeed);
    }
    
}
package net;

import java.util.Timer;
import java.util.TimerTask;

public class Conductor implements Runnable {

    public Timer gameTick = new Timer();
    public int tickSpeed = 200;

    @Override
    public void run() {
        timer();
    }

    public void timer() {
        TimerTask tick = new TimerTask() {
            @Override
            public void run() {
                for (int i = 0; i < Server.users.size(); i++) {
                    Server.directions[i] = Server.users.get(i).direction;
                }
                try {
                    if (game.Board.terminate() == true) gameTick.cancel();
                } catch (Exception e1) {

                }
                for (int i = 0; i < Server.users.size(); i++) {
                    for (int j = 0; j < Server.users.size(); j++) {
                        try {
                            Server.users.get(j).serverOut.writeUTF(i + " " + Server.directions[i]);
                        } catch (Exception e) {
    
                        }
                    }
                }
            }
        };
        gameTick.scheduleAtFixedRate(tick, tickSpeed, tickSpeed);
    }

}
